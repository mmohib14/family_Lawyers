import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { PracticeAreasGrid } from './components/PracticeAreasGrid';
import { PracticeAreaModal } from './components/PracticeAreaModal';
import { EligibilityWidget } from './components/EligibilityWidget';
import { CaseResultsSection } from './components/CaseResultsSection';
import { AttorneyProfiles } from './components/AttorneyProfiles';
import { ContactAndFooter } from './components/ContactAndFooter';
import { ConsultationSchedulerModal } from './components/ConsultationSchedulerModal';
import { ChatWidget } from './components/ChatWidget';
import { StickyMobileBar } from './components/StickyMobileBar';
import { AdminLeadsModal } from './components/AdminLeadsModal';
import { PRACTICE_AREAS } from './data/legalData';
import { CheckCircle2, X } from 'lucide-react';

export default function App() {
  const [schedulerOpen, setSchedulerOpen] = useState(false);
  const [prefilledPracticeArea, setPrefilledPracticeArea] = useState<string | undefined>(undefined);
  const [selectedPracticeAreaId, setSelectedPracticeAreaId] = useState<string | null>(null);
  const [adminLeadsOpen, setAdminLeadsOpen] = useState(false);

  // Global toast notification for verified lead dispatch
  const [toastNotification, setToastNotification] = useState<{ id: string; name: string } | null>(null);

  const handleOpenScheduler = (practiceAreaId?: string) => {
    setPrefilledPracticeArea(practiceAreaId);
    setSchedulerOpen(true);
  };

  const handleScrollToEligibility = () => {
    const el = document.getElementById('case-eligibility');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleLeadSubmitted = (id: string, name: string) => {
    setToastNotification({ id, name });
    setTimeout(() => {
      setToastNotification(null);
    }, 8000);
  };

  const selectedPracticeArea = PRACTICE_AREAS.find((pa) => pa.id === selectedPracticeAreaId) || null;

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#334155] flex flex-col selection:bg-amber-100 selection:text-amber-900 font-sans">
      {/* Toast Notification for Lead Capture Dispatched */}
      {toastNotification && (
        <div className="fixed top-14 right-4 z-50 bg-[#0F172A] border border-amber-500/60 text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 animate-in slide-in-from-top-4 duration-300 max-w-md">
          <div className="w-8 h-8 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div className="text-xs">
            <p className="font-bold text-amber-400">Intake Dispatched to Duty Attorney</p>
            <p className="text-slate-300">
              Case #{toastNotification.id} logged for {toastNotification.name}. Response team notified.
            </p>
          </div>
          <button
            onClick={() => setToastNotification(null)}
            className="text-slate-400 hover:text-white ml-1 p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 1. Header / Navigation Bar */}
      <Header
        onOpenScheduler={handleOpenScheduler}
        onOpenPracticeArea={(id) => setSelectedPracticeAreaId(id)}
        onOpenAdminLeads={() => setAdminLeadsOpen(true)}
      />

      <main className="flex-1">
        {/* 2. Hero Section */}
        <Hero
          onOpenScheduler={() => handleOpenScheduler()}
          onScrollToEligibility={handleScrollToEligibility}
        />

        {/* 3. Practice Areas Grid */}
        <PracticeAreasGrid
          onOpenPracticeArea={(id) => setSelectedPracticeAreaId(id)}
          onOpenScheduler={handleOpenScheduler}
        />

        {/* 4. Interactive Case Eligibility Check */}
        <EligibilityWidget onLeadSubmitted={handleLeadSubmitted} />

        {/* 5. Case Results & Social Proof */}
        <CaseResultsSection onOpenScheduler={handleOpenScheduler} />

        {/* 6. Attorney Profiles */}
        <AttorneyProfiles onOpenScheduler={handleOpenScheduler} />
      </main>

      {/* 7. Contact & Footer */}
      <ContactAndFooter
        onOpenScheduler={handleOpenScheduler}
        onOpenPracticeArea={(id) => setSelectedPracticeAreaId(id)}
        onLeadSuccess={handleLeadSubmitted}
      />

      {/* 24/7 AI / Live Chat Widget Overlay */}
      <ChatWidget onOpenScheduler={handleOpenScheduler} />

      {/* Mobile-First Sticky Bottom Action Bar (Call Now | Book Online) */}
      <StickyMobileBar onOpenScheduler={() => handleOpenScheduler()} />

      {/* Interactive Intake & Consultation Scheduler Modal */}
      <ConsultationSchedulerModal
        isOpen={schedulerOpen}
        onClose={() => setSchedulerOpen(false)}
        prefillPracticeArea={prefilledPracticeArea}
        onLeadSuccess={handleLeadSubmitted}
      />

      {/* SEO-Optimized Practice Area Deep-Dive Modal */}
      <PracticeAreaModal
        practiceArea={selectedPracticeArea}
        onClose={() => setSelectedPracticeAreaId(null)}
        onOpenScheduler={handleOpenScheduler}
      />

      {/* Admin Leads Management Console */}
      <AdminLeadsModal
        isOpen={adminLeadsOpen}
        onClose={() => setAdminLeadsOpen(false)}
      />
    </div>
  );
}
