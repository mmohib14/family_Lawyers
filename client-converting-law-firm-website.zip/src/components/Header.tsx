import React, { useState } from 'react';
import { Phone, Calendar, Shield, Menu, X, Scale, ChevronDown, Clock } from 'lucide-react';
import { PRACTICE_AREAS } from '../data/legalData';

interface HeaderProps {
  onOpenScheduler: (prefillPracticeArea?: string) => void;
  onOpenPracticeArea: (id: string) => void;
  onOpenAdminLeads?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenScheduler,
  onOpenPracticeArea,
  onOpenAdminLeads
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [practiceDropdownOpen, setPracticeDropdownOpen] = useState(false);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    setPracticeDropdownOpen(false);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full shadow-sm bg-white">
      {/* Click-to-Call Sticky Top Alert Banner */}
      <div className="bg-[#0F172A] text-slate-200 text-xs sm:text-sm py-2 px-4 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-center sm:text-left">
            <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-medium text-slate-300">
              Immediate Case Intake Available 24/7/365:
            </span>
            <span className="text-amber-400 font-semibold hidden md:inline">
              100% Free & Confidential Consultation
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 text-slate-400 hidden lg:flex">
              <Clock className="w-3.5 h-3.5 text-amber-500" />
              <span>Average response time: &lt; 15 minutes</span>
            </div>

            <a
              id="header-top-tel"
              href="tel:+18005550199"
              className="flex items-center gap-1.5 text-amber-400 hover:text-amber-300 font-bold tracking-wide transition-colors py-0.5 px-2 rounded bg-slate-800/80 hover:bg-slate-800"
            >
              <Phone className="w-3.5 h-3.5 fill-current" />
              <span>(800) 555-0199</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
        {/* Law Firm Crest & Brand */}
        <div
          id="brand-logo"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-lg bg-[#0F172A] border border-amber-600/40 flex items-center justify-center text-amber-500 shadow-sm group-hover:border-amber-500 transition-colors">
            <Scale className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-serif-display font-bold text-xl sm:text-2xl text-[#0F172A] tracking-tight">
                Vanguard &amp; Sterling
              </span>
            </div>
            <p className="text-[11px] uppercase tracking-widest text-[#D97706] font-semibold">
              Trial Attorneys &amp; Legal Counsel
            </p>
          </div>
        </div>

        {/* Desktop Nav Links */}
        <div className="hidden lg:flex items-center gap-7 text-[15px] font-medium text-[#334155]">
          {/* Practice Areas Dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setPracticeDropdownOpen(true)}
            onMouseLeave={() => setPracticeDropdownOpen(false)}
          >
            <button
              id="nav-practice-areas-btn"
              onClick={() => scrollToSection('practice-areas')}
              className="flex items-center gap-1 hover:text-[#0F172A] py-2 transition-colors"
            >
              <span>Practice Areas</span>
              <ChevronDown className="w-4 h-4 text-slate-400 group-hover:text-slate-600 transition-transform duration-150" />
            </button>

            {practiceDropdownOpen && (
              <div className="absolute top-full left-0 w-80 bg-white border border-slate-200 rounded-xl shadow-xl py-2 px-1 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
                <div className="px-3 py-1.5 border-b border-slate-100 mb-1">
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    Core Specializations
                  </p>
                </div>
                {PRACTICE_AREAS.map((pa) => (
                  <button
                    key={pa.id}
                    onClick={() => {
                      setPracticeDropdownOpen(false);
                      onOpenPracticeArea(pa.id);
                    }}
                    className="w-full text-left px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 hover:text-amber-700 rounded-lg flex items-center justify-between group transition-colors"
                  >
                    <span className="font-medium">{pa.title}</span>
                    <span className="text-[11px] text-amber-600 font-semibold opacity-0 group-hover:opacity-100 transition-opacity">
                      Deep Dive →
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={() => scrollToSection('case-eligibility')}
            className="hover:text-[#0F172A] transition-colors py-2"
          >
            Case Eligibility
          </button>

          <button
            onClick={() => scrollToSection('case-results')}
            className="hover:text-[#0F172A] transition-colors py-2"
          >
            Verdicts &amp; Settlements
          </button>

          <button
            onClick={() => scrollToSection('attorneys')}
            className="hover:text-[#0F172A] transition-colors py-2"
          >
            Our Attorneys
          </button>

          <button
            onClick={() => scrollToSection('reviews')}
            className="hover:text-[#0F172A] transition-colors py-2"
          >
            Reviews
          </button>

          <button
            onClick={() => scrollToSection('contact-section')}
            className="hover:text-[#0F172A] transition-colors py-2"
          >
            Contact
          </button>
        </div>

        {/* Desktop Dual Action Buttons */}
        <div className="hidden sm:flex items-center gap-3">
          <a
            id="nav-call-btn"
            href="tel:+18005550199"
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-lg border border-slate-300 text-slate-800 text-sm font-semibold hover:bg-slate-50 hover:border-slate-400 transition-colors"
          >
            <Phone className="w-4 h-4 text-amber-600" />
            <span>(800) 555-0199</span>
          </a>

          <button
            id="nav-book-consultation-btn"
            onClick={() => onOpenScheduler()}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#D97706] hover:bg-[#b45309] text-white text-sm font-semibold shadow-sm hover:shadow transition-all duration-150 active:scale-[0.99]"
          >
            <Calendar className="w-4 h-4" />
            <span>Book Consultation</span>
          </button>

          {onOpenAdminLeads && (
            <button
              id="admin-leads-trigger"
              onClick={onOpenAdminLeads}
              title="Intake Leads Management"
              className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors text-xs"
            >
              <Shield className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Mobile Hamburger Toggle */}
        <div className="flex sm:hidden items-center gap-2">
          <a
            href="tel:+18005550199"
            className="p-2 text-amber-600 bg-amber-50 rounded-lg"
            aria-label="Call law firm"
          >
            <Phone className="w-5 h-5" />
          </a>
          <button
            id="mobile-menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-slate-700 hover:bg-slate-100 rounded-lg focus:outline-none"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-2 pb-6 space-y-3 shadow-lg">
          <div className="space-y-1">
            <button
              onClick={() => scrollToSection('practice-areas')}
              className="w-full text-left px-3 py-2 text-slate-800 font-medium rounded hover:bg-slate-100"
            >
              Practice Areas
            </button>
            <button
              onClick={() => scrollToSection('case-eligibility')}
              className="w-full text-left px-3 py-2 text-slate-800 font-medium rounded hover:bg-slate-100"
            >
              Interactive Case Eligibility Check
            </button>
            <button
              onClick={() => scrollToSection('case-results')}
              className="w-full text-left px-3 py-2 text-slate-800 font-medium rounded hover:bg-slate-100"
            >
              Verdicts &amp; Settlements ($185M+)
            </button>
            <button
              onClick={() => scrollToSection('attorneys')}
              className="w-full text-left px-3 py-2 text-slate-800 font-medium rounded hover:bg-slate-100"
            >
              Attorney Profiles
            </button>
            <button
              onClick={() => scrollToSection('reviews')}
              className="w-full text-left px-3 py-2 text-slate-800 font-medium rounded hover:bg-slate-100"
            >
              Client Reviews
            </button>
            <button
              onClick={() => scrollToSection('contact-section')}
              className="w-full text-left px-3 py-2 text-slate-800 font-medium rounded hover:bg-slate-100"
            >
              Offices &amp; Contact
            </button>
          </div>

          <div className="pt-2 border-t border-slate-100 space-y-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenScheduler();
              }}
              className="w-full flex items-center justify-center gap-2 py-3 bg-[#D97706] text-white font-semibold rounded-lg shadow"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Free Consultation</span>
            </button>
            <a
              href="tel:+18005550199"
              className="w-full flex items-center justify-center gap-2 py-3 bg-slate-900 text-amber-400 font-bold rounded-lg"
            >
              <Phone className="w-4 h-4 fill-current" />
              <span>Call 24/7: (800) 555-0199</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
