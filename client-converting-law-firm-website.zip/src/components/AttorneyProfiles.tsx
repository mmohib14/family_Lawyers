import React, { useState } from 'react';
import { Award, GraduationCap, ShieldCheck, Calendar, Phone, ArrowRight, Quote } from 'lucide-react';
import { ATTORNEYS } from '../data/legalData';
import { Attorney } from '../types';

interface AttorneyProfilesProps {
  onOpenScheduler: (prefillPracticeArea?: string) => void;
}

export const AttorneyProfiles: React.FC<AttorneyProfilesProps> = ({
  onOpenScheduler
}) => {
  const [selectedAttorney, setSelectedAttorney] = useState<Attorney | null>(null);

  return (
    <section id="attorneys" className="py-20 bg-[#F8FAFC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-200 text-slate-800 text-xs font-bold uppercase tracking-wider">
            <Award className="w-3.5 h-3.5 text-amber-600" />
            <span>Senior Courtroom Litigators</span>
          </div>
          <h2 className="font-serif-display text-3xl sm:text-4xl md:text-5xl font-bold text-[#0F172A] tracking-tight">
            Meet Our Trial Partners
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Our partners do not hand your future to junior paralegals. You are represented directly by veteran trial attorneys with decades of federal and state courtroom dominance.
          </p>
        </div>

        {/* Attorney Grid */}
        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {ATTORNEYS.map((at) => (
            <div
              key={at.id}
              className="bg-white rounded-2xl border border-slate-200/90 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                {/* Professional Portrait */}
                <div className="relative h-72 w-full overflow-hidden bg-slate-800">
                  <img
                    src={at.image}
                    alt={at.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] via-transparent to-transparent opacity-80" />

                  {/* Recovered Overlay Pill */}
                  <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-md bg-amber-500 text-slate-950 text-xs font-bold shadow">
                      {at.totalRecovered} Recovered
                    </span>
                    <span className="text-[11px] font-semibold text-slate-200 bg-slate-900/80 px-2 py-0.5 rounded">
                      {at.experienceYears} Yrs Practice
                    </span>
                  </div>
                </div>

                {/* Profile Details */}
                <div className="p-6 space-y-4">
                  <div>
                    <h3 className="font-serif-display text-xl font-bold text-[#0F172A] group-hover:text-amber-700 transition-colors">
                      {at.name}
                    </h3>
                    <p className="text-xs text-amber-700 font-semibold mt-0.5">
                      {at.title}
                    </p>
                  </div>

                  {/* Education & Credentials */}
                  <div className="space-y-1.5 text-xs text-slate-600">
                    <div className="flex items-start gap-1.5">
                      <GraduationCap className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                      <span className="line-clamp-2">{at.education}</span>
                    </div>
                  </div>

                  {/* Bar Admissions */}
                  <div className="space-y-1 pt-2 border-t border-slate-100">
                    <p className="text-[10px] uppercase tracking-wider font-bold text-slate-400">
                      Bar Admissions
                    </p>
                    <div className="flex flex-wrap gap-1">
                      {at.admissions.map((adm, i) => (
                        <span key={i} className="text-[11px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                          {adm}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Attorney Quote */}
                  <p className="text-xs text-slate-500 italic line-clamp-2 pt-1">
                    "{at.quotes}"
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center gap-2">
                <button
                  onClick={() => setSelectedAttorney(at)}
                  className="flex-1 py-2 text-xs font-semibold text-slate-700 hover:text-[#0F172A] border border-slate-300 rounded-lg hover:bg-white transition-colors"
                >
                  Full Biography
                </button>
                <button
                  onClick={() => onOpenScheduler()}
                  className="flex-1 py-2 text-xs font-bold text-white bg-[#0F172A] hover:bg-[#D97706] rounded-lg transition-colors flex items-center justify-center gap-1"
                >
                  <span>Book Partner</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Selected Attorney Biography Modal */}
        {selectedAttorney && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-in fade-in duration-150">
            <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-slate-200 shadow-2xl p-6 sm:p-8 space-y-6">
              <div className="flex items-start gap-5">
                <img
                  src={selectedAttorney.image}
                  alt={selectedAttorney.name}
                  referrerPolicy="no-referrer"
                  className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover object-top border border-slate-200 shrink-0"
                />
                <div className="space-y-1">
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 text-xs font-bold">
                    {selectedAttorney.totalRecovered} Recovered
                  </span>
                  <h3 className="font-serif-display text-2xl font-bold text-slate-900">
                    {selectedAttorney.name}
                  </h3>
                  <p className="text-xs text-slate-600 font-semibold">
                    {selectedAttorney.title}
                  </p>
                  <p className="text-xs text-slate-500">
                    {selectedAttorney.education}
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-bold text-sm text-slate-900 uppercase tracking-wider">
                  Biography &amp; Courtroom Record
                </h4>
                <p className="text-sm text-slate-600 leading-relaxed">
                  {selectedAttorney.bio}
                </p>
              </div>

              <div className="space-y-2">
                <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider">
                  Honors &amp; Appointments
                </h4>
                <div className="space-y-1.5">
                  {selectedAttorney.awards.map((award, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs text-slate-700">
                      <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>{award}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-3">
                <button
                  onClick={() => setSelectedAttorney(null)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-50"
                >
                  Close
                </button>

                <button
                  onClick={() => {
                    const at = selectedAttorney;
                    setSelectedAttorney(null);
                    onOpenScheduler();
                  }}
                  className="px-6 py-2.5 bg-[#D97706] hover:bg-[#b45309] text-white text-sm font-bold rounded-xl shadow flex items-center gap-2"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Schedule Consultation with {selectedAttorney.name.split(',')[0]}</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
