import React from 'react';
import { Phone, Calendar } from 'lucide-react';

interface StickyMobileBarProps {
  onOpenScheduler: () => void;
}

export const StickyMobileBar: React.FC<StickyMobileBarProps> = ({ onOpenScheduler }) => {
  return (
    <div className="sm:hidden fixed bottom-0 left-0 right-0 z-30 bg-[#0F172A] border-t border-slate-800 p-2.5 px-4 flex items-center gap-3 shadow-2xl backdrop-blur-md">
      {/* 1-Click Dialing Button */}
      <a
        id="mobile-sticky-call-btn"
        href="tel:+18005550199"
        className="flex-1 py-3 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold text-xs flex items-center justify-center gap-2 border border-slate-700 active:scale-98 transition-all"
      >
        <Phone className="w-4 h-4 fill-current" />
        <span>Call (800) 555-0199</span>
      </a>

      {/* Book Online Button */}
      <button
        id="mobile-sticky-book-btn"
        onClick={onOpenScheduler}
        className="flex-1 py-3 px-3 rounded-xl bg-[#D97706] hover:bg-[#b45309] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg active:scale-98 transition-all"
      >
        <Calendar className="w-4 h-4" />
        <span>Book Online Free</span>
      </button>
    </div>
  );
};
